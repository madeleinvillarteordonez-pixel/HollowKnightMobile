import os
import pygame

# Intenta importar constantes; si no existen, usa valores seguros por defecto
try:
    from constants import ANCHO, ALTO, GRAVEDAD, VELOCIDAD_JUGADOR, FUERZA_SALTO
except ImportError:
    ANCHO, ALTO = 800, 480
    GRAVEDAD = 0.8
    VELOCIDAD_JUGADOR = 5
    FUERZA_SALTO = -14

class PlayerChar(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        
        # Dimensiones del personaje
        self.ANCHO_SPRITE = 60
        self.ALTO_SPRITE = 80

        self.images_raw = {}
        self.animations = {
            "quieto": [],
            "caminar": [],
            "atacar": [],
            "saltar": [],
            "volar": [],
            "frente": [],
            "muerto": []
        }
        
        self.cargar_todas_las_imagenes()
        self.organizar_animaciones()
        
        # Animación
        self.estado_actual = "quieto"
        self.frame_index = 0.0
        self.vel_anim = 0.2
        self.atacando = False
        self.esta_muerto = False

        self.image_base = self._get_frame_actual()
        self.image = self.image_base.copy()
        self.rect = self.image.get_rect(topleft=(x, y))
        
        # Físicas
        self.vel_x = 0
        self.vel_y = 0
        self.en_suelo = False
        self.mirando_izquierda = False

    def limpiar_fondo_verde(self, ruta_imagen):
        """
        Elimina el verde neón de 'morir.png' e imágenes con croma
        ignorando trazos o bordes blancos.
        """
        try:
            image_loaded = pygame.image.load(ruta_imagen)
            if pygame.display.get_surface() is not None:
                surface = image_loaded.convert_alpha()
            else:
                surface = image_loaded

            ancho, alto = surface.get_size()

            for px in range(ancho):
                for py in range(alto):
                    r, g, b, a = surface.get_at((px, py))
                    if a == 0:
                        continue

                    # 1. Borrar verde neón (donde G sea el color dominante)
                    # Cubre tanto el fondo principal como el círculo verde interno.
                    if g > 120 and g > r * 1.2 and g > b * 1.2:
                        surface.set_at((px, py), (0, 0, 0, 0))

                    # 2. Borrar las líneas/garabatos blancos de los bordes superiores
                    elif r > 200 and g > 200 and b > 200 and (py < 20 or px < 20):
                        surface.set_at((px, py), (0, 0, 0, 0))

            return pygame.transform.smoothscale(surface, (self.ANCHO_SPRITE, self.ALTO_SPRITE))

        except Exception as e:
            print(f"[ERROR] No se pudo procesar la imagen {ruta_imagen}: {e}")
            fallback = pygame.Surface((self.ANCHO_SPRITE, self.ALTO_SPRITE), pygame.SRCALPHA)
            fallback.fill((200, 0, 0))
            return fallback

    def cargar_todas_las_imagenes(self):
        carpeta_img = os.path.join("assets", "img")
        if os.path.exists(carpeta_img):
            for archivo in os.listdir(carpeta_img):
                if archivo.lower().endswith((".png", ".jpg", ".jpeg")):
                    nombre_clave = os.path.splitext(archivo)[0].lower()
                    ruta_completa = os.path.join(carpeta_img, archivo)
                    self.images_raw[nombre_clave] = self.limpiar_fondo_verde(ruta_completa)

    def organizar_animaciones(self):
        # Quieto
        if "quieto" in self.images_raw:
            self.animations["quieto"].append(self.images_raw["quieto"])

        # Caminar
        for k in ["caminar", "caminar_1", "caminar_2", "caminar_3", "correr", "correr_1", "correr_2"]:
            if k in self.images_raw:
                self.animations["caminar"].append(self.images_raw[k])
        if not self.animations["caminar"] and "quieto" in self.images_raw:
            self.animations["caminar"].append(self.images_raw["quieto"])

        # Atacar
        for k in ["atacar", "atacar_1", "atacar_2"]:
            if k in self.images_raw:
                self.animations["atacar"].append(self.images_raw[k])

        # Saltar / Volar
        if "saltar" in self.images_raw: self.animations["saltar"].append(self.images_raw["saltar"])
        if "volar" in self.images_raw: self.animations["volar"].append(self.images_raw["volar"])

        # Muerte
        for k in ["morir", "muerto", "muerte"]:
            if k in self.images_raw:
                self.animations["muerto"].append(self.images_raw[k])

    def _get_frame_actual(self):
        frames = self.animations.get(self.estado_actual, [])
        if not frames:
            frames = self.animations.get("quieto", [])
        
        if frames:
            idx = int(self.frame_index) % len(frames)
            return frames[idx]
        
        surf = pygame.Surface((self.ANCHO_SPRITE, self.ALTO_SPRITE), pygame.SRCALPHA)
        surf.fill((200, 200, 200))
        return surf

    def cambiar_estado(self, nuevo_estado):
        if self.estado_actual != nuevo_estado:
            self.estado_actual = nuevo_estado
            self.frame_index = 0.0

    def move_x(self, vel):
        if self.esta_muerto:
            return
        self.vel_x = vel
        if vel < 0:
            self.mirando_izquierda = True
        elif vel > 0:
            self.mirando_izquierda = False

    def saltar(self):
        if self.en_suelo and not self.esta_muerto:
            self.vel_y = FUERZA_SALTO
            self.en_suelo = False

    def atacar(self):
        if not self.atacando and not self.esta_muerto and self.animations["atacar"]:
            self.atacando = True
            self.cambiar_estado("atacar")

    def morir(self):
        """Activa el estado de muerte utilizando la imagen procesada de morir."""
        self.esta_muerto = True
        self.atacando = False
        self.vel_x = 0
        self.cambiar_estado("muerto")

    def animate(self):
        # Selección de estado
        if self.esta_muerto:
            self.cambiar_estado("muerto")
            if not self.animations["muerto"]:
                base = self.animations.get("quieto", [self.image_base])[0]
                self.image_base = pygame.transform.rotate(base, 90)
            else:
                self.image_base = self._get_frame_actual()
        else:
            if self.atacando:
                self.cambiar_estado("atacar")
            elif not self.en_suelo:
                if self.animations["saltar"]:
                    self.cambiar_estado("saltar")
                elif self.animations["volar"]:
                    self.cambiar_estado("volar")
            elif self.vel_x != 0:
                self.cambiar_estado("caminar")
            else:
                self.cambiar_estado("quieto")

            # Avance de frame
            frames = self.animations.get(self.estado_actual, [])
            if frames:
                self.frame_index += self.vel_anim
                if self.estado_actual == "atacar" and self.frame_index >= len(frames):
                    self.atacando = False
                    self.frame_index = 0.0
                    self.cambiar_estado("quieto")

            self.image_base = self._get_frame_actual()

        # Volteo horizontal
        if self.mirando_izquierda:
            self.image = pygame.transform.flip(self.image_base, True, False)
        else:
            self.image = self.image_base.copy()

    def update(self, plataformas):
        # Gravedad
        self.vel_y += GRAVEDAD
        if self.vel_y > 14:
            self.vel_y = 14

        # Movimiento Horizontal + Colisiones
        self.rect.x += self.vel_x

        # Límite para no pasar la pared de la pantalla izquierda y derecha
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > ANCHO:
            self.rect.right = ANCHO

        colisiones_x = pygame.sprite.spritecollide(self, plataformas, False)
        for p in colisiones_x:
            if self.vel_x > 0:
                self.rect.right = p.rect.left
            elif self.vel_x < 0:
                self.rect.left = p.rect.right

        # Movimiento Vertical + Colisiones
        self.rect.y += self.vel_y
        self.en_suelo = False
        colisiones_y = pygame.sprite.spritecollide(self, plataformas, False)
        for p in colisiones_y:
            if self.vel_y > 0:
                self.rect.bottom = p.rect.top
                self.vel_y = 0
                self.en_suelo = True
            elif self.vel_y < 0:
                self.rect.top = p.rect.bottom
                self.vel_y = 0

        self.animate()









