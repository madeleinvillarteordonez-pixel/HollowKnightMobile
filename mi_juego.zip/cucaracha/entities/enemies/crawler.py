# Guardar como: entities/enemies/crawler.py

import pygame
# Importar constantes desde la raíz
from constants import GRAVEDAD

class Crawler(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        # Usar transparencia Alpha por si acaso
        self.image = pygame.Surface((35, 35)).convert_alpha()
        self.image.fill((200, 50, 50)) # Cuadrado rojo representativo
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        self.velocidad_x = 2 
        self.velocidad_y = 0
        self.limite_izquierdo = x - 100
        self.limite_derecho = x + 100

    def update(self, plataformas):
        # Físicas básicas y gravedad
        self.velocidad_y += GRAVEDAD
        self.rect.y += self.velocidad_y
        
        # Colisiones verticales
        for plataforma in plataformas:
            if self.rect.colliderect(plataforma.rect):
                if self.velocidad_y > 0:
                    self.rect.bottom = plataforma.rect.top
                    self.velocidad_y = 0

        # Movimiento horizontal patrullando
        self.rect.x += self.velocidad_x
        if self.rect.x >= self.limite_derecho or self.rect.x <= self.limite_izquierdo:
            self.velocidad_x *= -1

