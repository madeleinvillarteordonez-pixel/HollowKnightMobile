import os
import cv2

# Ruta de la carpeta donde se guardarán las imágenes
carpeta_destino = os.path.join("assets", "img", "fondo_frames")
os.makedirs(carpeta_destino, exist_ok=True)

ruta_video = os.path.join("assets", "img", "fondo.mp4")

if os.path.exists(ruta_video):
    cap = cv2.VideoCapture(ruta_video)
    count = 0
    saved = 0
    print("Extrayendo fotogramas de fondo.mp4...")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        # Guarda 1 de cada 2 cuadros para optimizar memoria
        if count % 2 == 0:
            nombre_foto = os.path.join(carpeta_destino, f"frame_{saved:04d}.jpg")
            cv2.imwrite(nombre_foto, frame)
            saved += 1
        count += 1
        
    cap.release()
    print(f"¡Listo! Se guardaron {saved} imágenes en: {carpeta_destino}")
else:
    print(f"ERROR: No se encontró el archivo {ruta_video}")