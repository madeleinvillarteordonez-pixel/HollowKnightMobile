# Guardar como: constants.py

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
FPS = 60

# Físicas iniciales para el personaje
VELOCIDAD_JUGADOR = 6
GRAVEDAD = 0.8
FUERZA_SALTO = -16