import os
import sys
import math
import pygame

from constants import ANCHO, ALTO, FPS, VELOCIDAD_JUGADOR
from entities.player import PlayerChar

pygame.init()
pygame.mixer.init()
pygame.font.init()

pantalla = pygame.display.set_mode((ANCHO, ALTO), pygame.SCALED)
pygame.display.set_caption("Hollow Knight: Mobile Edition")
reloj = pygame.time.Clock()

# --- PALETA DE COLORES MODERNA ---
COLOR_BG_DARK = (10, 10, 18)
COLOR_CARD_BG = (20, 22, 35, 200)
COLOR_ACCENT_GOLD = (255, 215, 0)
COLOR_NEON_BLUE = (0, 210, 255)
COLOR_NEON_RED = (255, 65, 84)
COLOR_TEXT_MAIN = (240, 242, 250)
COLOR_TEXT_MUTED = (140, 145, 170)
COLOR_BTN_TACTIL = (255, 255, 255, 40)
COLOR_BTN_TACTIL_ACTIVO = (0, 210, 255, 100)

# --- FUENTES MODERNAS ---
fuente_ui = pygame.font.SysFont("segoeui, arial", 13, bold=True)
fuente_dialogo = pygame.font.SysFont("segoeui, arial", 15, bold=True)
fuente_menu = pygame.font.SysFont("segoeui, arial", 16, bold=True)
fuente_titulo = pygame.font.SysFont("segoeui, arial", 24, bold=True)
fuente_gameover = pygame.font.SysFont("segoeui, arial", 36, bold=True)

ESTADO_MENU_PRINCIPAL = "menu_principal"
ESTADO_SELECCION_HISTORIA = "menu_historia"
ESTADO_JUEGO = "juego"
ESTADO_MUERTE_ANIMACION = "muerte_anim"
ESTADO_GAME_OVER = "game_over"
ESTADO_VICTORIA = "victoria"

estado_actual = ESTADO_MENU_PRINCIPAL
nivel_actual = 0
nivel_maximo_desbloqueado = 0

INSTRUCCIONES_NIVELES = {
    0: "¡Bienvenido! Usa las FLECHAS en pantalla o teclado para moverte.",
    1: "Capítulo 1: Salta sobre las plataformas y elimina a los centinelas.",
    2: "Capítulo 2: ¡Cuidado! Las plataformas rojas provocan daño directo.",
    3: "Capítulo 3: Los villanos disparan orbes oscuros. Mantén tu distancia.",
    4: "Capítulo 4: Mantén el ritmo en los saltos para esquivar la patrulla.",
    5: "Capítulo 5: Zonas de alto riesgo. Un fallo en el salto resultará en daño.",
    6: "Capítulo 6: Los enemigos incrementan su velocidad. Ataca con precisión.",
    7: "Capítulo 7: Terreno minado. Apóyate exclusivamente en las zonas elevadas.",
    8: "¡CAPÍTULO FINAL! Derrota al Jefe Supremo para rescatar a tu hermana."
}

tiempo_instruccion = 0

# --- RECURSOS ---
avatar_personaje = None
ruta_avatar = os.path.join("assets", "personaje_guia.png")
if os.path.exists(ruta_avatar):
    avatar_personaje = pygame.image.load(ruta_avatar).convert_alpha()
    avatar_personaje = pygame.transform.scale(avatar_personaje, (50, 50))

img_muerte = None
ruta_muerte = os.path.join("assets", "img", "morir.png")
if os.path.exists(ruta_muerte):
    img_muerte = pygame.image.load(ruta_muerte).convert_alpha()
    img_muerte.set_colorkey((0, 255, 0))

# --- CLASES Y SPRITES ---
class Plataforma(pygame.sprite.Sprite):
    def __init__(self, x, y, ancho, alto, es_obstaculo=False):
        super().__init__()
        self.es_obstaculo = es_obstaculo
        self.image = pygame.Surface((ancho, alto), pygame.SRCALPHA)
        color = COLOR_NEON_RED if es_obstaculo else (35, 40, 60, 220)
        pygame.draw.rect(self.image, color, (0, 0, ancho, alto), border_radius=6)
        
        borde_color = (255, 100, 100) if es_obstaculo else COLOR_NEON_BLUE
        pygame.draw.rect(self.image, borde_color, (0, 0, ancho, alto), width=2, border_radius=6)
        self.rect = self.image.get_rect(topleft=(x, y))

class PuertaCueva(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((45, 65), pygame.SRCALPHA)
        pygame.draw.rect(self.image, (15, 15, 25), (0, 0, 45, 65), border_radius=12)
        pygame.draw.rect(self.image, COLOR_ACCENT_GOLD, (0, 0, 45, 65), width=3, border_radius=12)
        pygame.draw.circle(self.image, COLOR_ACCENT_GOLD, (22, 32), 6)
        self.rect = self.image.get_rect(topleft=(x, y))

class Hermana(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((32, 48), pygame.SRCALPHA)
        pygame.draw.ellipse(self.image, (240, 120, 180), (0, 10, 32, 38))
        pygame.draw.circle(self.image, COLOR_TEXT_MAIN, (16, 12), 10)
        pygame.draw.circle(self.image, COLOR_ACCENT_GOLD, (16, 2), 5)
        self.rect = self.image.get_rect(topleft=(x, y))

class PoderVillano(pygame.sprite.Sprite):
    def __init__(self, x, y, vx, vy):
        super().__init__()
        self.image = pygame.Surface((14, 14), pygame.SRCALPHA)
        pygame.draw.circle(self.image, COLOR_NEON_RED, (7, 7), 7)
        pygame.draw.circle(self.image, COLOR_ACCENT_GOLD, (7, 7), 3)
        self.rect = self.image.get_rect(center=(x, y))
        self.vx = vx
        self.vy = vy

    def update(self):
        self.rect.x += self.vx
        self.rect.y += self.vy
        if self.rect.right < 0 or self.rect.left > ANCHO or self.rect.bottom < 0 or self.rect.top > ALTO:
            self.kill()

class EnemigoBase(pygame.sprite.Sprite):
    def __init__(self, x, y, rango_mov=80, velocidad=2, es_jefe=False, vida=1, dispara=True):
        super().__init__()
        self.es_jefe = es_jefe
        self.vida = vida
        self.vida_max = vida
        self.dispara = dispara
        self.cadencia_disparo = 80 if es_jefe else 130
        self.cooldown_disparo = self.cadencia_disparo
        
        tam = 56 if es_jefe else 36
        self.image_base = pygame.Surface((tam, tam), pygame.SRCALPHA)
        color = (180, 20, 40) if es_jefe else (210, 50, 50)
        pygame.draw.circle(self.image_base, color, (tam // 2, tam // 2), tam // 2)
        pygame.draw.circle(self.image_base, COLOR_TEXT_MAIN, (tam // 3, tam // 3), tam // 7)
        pygame.draw.circle(self.image_base, COLOR_TEXT_MAIN, (2 * tam // 3, tam // 3), tam // 7)
        pygame.draw.circle(self.image_base, (10, 10, 10), (tam // 3, tam // 3), tam // 14)
        pygame.draw.circle(self.image_base, (10, 10, 10), (2 * tam // 3, tam // 3), tam // 14)

        self.image = self.image_base.copy()
        self.rect = self.image.get_rect(topleft=(x, y))
        self.x_inicio = x
        self.rango = rango_mov
        self.vel = velocidad

    def update(self, grupo_poderes, pos_jugador):
        self.rect.x += self.vel
        if abs(self.rect.x - self.x_inicio) > self.rango:
            self.vel *= -1

        if self.dispara:
            self.cooldown_disparo -= 1
            if self.cooldown_disparo <= 0:
                self.cooldown_disparo = self.cadencia_disparo
                dx = pos_jugador[0] - self.rect.centerx
                dy = pos_jugador[1] - self.rect.centery
                distancia = math.hypot(dx, dy)
                if distancia != 0:
                    vel_p = 5.5 if self.es_jefe else 3.8
                    vx = (dx / distancia) * vel_p
                    vy = (dy / distancia) * vel_p
                    grupo_poderes.add(PoderVillano(self.rect.centerx, self.rect.centery, vx, vy))

    def recibir_dano(self, dano=1):
        self.vida -= dano
        if self.vida <= 0:
            self.kill()

# --- SISTEMA DE VIDA Y MUERTE ---
vida_maxima = 100
vida_actual = 100
tiempo_invulnerable = 0
vel_caida_muerte = 0

def recibir_dano(cantidad):
    global vida_actual, tiempo_invulnerable, estado_actual, vel_caida_muerte
    if tiempo_invulnerable <= 0 and estado_actual == ESTADO_JUEGO:
        vida_actual -= cantidad
        tiempo_invulnerable = 40
        if vida_actual <= 0:
            vida_actual = 0
            vel_caida_muerte = -7
            estado_actual = ESTADO_MUERTE_ANIMACION

def dibujar_barra_vida_moderna(superficie, x, y, vida, vida_max, titulo="HP"):
    ancho_bar, alto_bar = 160, 16
    porcentaje = max(0, vida / vida_max)
    
    s = pygame.Surface((ancho_bar + 4, alto_bar + 4), pygame.SRCALPHA)
    s.fill((15, 18, 30, 220))
    superficie.blit(s, (x - 2, y - 2))
    
    color_barra = COLOR_ACCENT_GOLD if porcentaje > 0.35 else COLOR_NEON_RED
    if porcentaje > 0.0:
        pygame.draw.rect(superficie, color_barra, (x, y, int(ancho_bar * porcentaje), alto_bar), border_radius=4)
        
    pygame.draw.rect(superficie, (255, 255, 255, 60), (x, y, ancho_bar, alto_bar), width=1, border_radius=4)
    
    txt_v = fuente_ui.render(f"{titulo} {int(vida)}/{vida_max}", True, COLOR_TEXT_MAIN)
    superficie.blit(txt_v, (x + 8, y + 1))

def dibujar_dialogo_moderno(superficie, texto):
    ancho_box, alto_box = 620, 70
    rect_box = pygame.Rect((ANCHO - ancho_box) // 2, ALTO - 165, ancho_box, alto_box)
    
    s = pygame.Surface((rect_box.width, rect_box.height), pygame.SRCALPHA)
    s.fill((12, 14, 24, 235))
    superficie.blit(s, rect_box.topleft)
    pygame.draw.rect(superficie, COLOR_NEON_BLUE, rect_box, width=2, border_radius=12)
    
    offset_x = 15
    if avatar_personaje:
        superficie.blit(avatar_personaje, (rect_box.x + 10, rect_box.y + 10))
        offset_x = 70

    txt_nombre = fuente_ui.render("GUÍA:", True, COLOR_NEON_BLUE)
    superficie.blit(txt_nombre, (rect_box.x + offset_x, rect_box.y + 10))

    txt_mensaje = fuente_dialogo.render(texto, True, COLOR_TEXT_MAIN)
    superficie.blit(txt_mensaje, (rect_box.x + offset_x, rect_box.y + 32))

def dibujar_boton_moderno(superficie, rect, texto, activo=True, resaltado=False):
    s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    bg_color = (30, 35, 55, 220) if activo else (20, 20, 28, 180)
    if resaltado and activo:
        bg_color = (45, 55, 85, 240)
        
    s.fill(bg_color)
    superficie.blit(s, rect.topleft)
    
    borde = COLOR_ACCENT_GOLD if resaltado else (COLOR_NEON_BLUE if activo else COLOR_TEXT_MUTED)
    pygame.draw.rect(superficie, borde, rect, width=2, border_radius=8)
    
    color_texto = COLOR_TEXT_MAIN if activo else COLOR_TEXT_MUTED
    txt_surf = fuente_menu.render(texto, True, color_texto)
    superficie.blit(txt_surf, txt_surf.get_rect(center=rect.center))

# --- CARGADOR DE FONDOS ---
def cargar_frames_carpeta(carpeta_relativa, prefijo):
    frames = []
    ruta_carpeta = os.path.join("assets", carpeta_relativa)
    if os.path.exists(ruta_carpeta):
        archivos = sorted([f for f in os.listdir(ruta_carpeta) if f.startswith(prefijo) and (f.endswith(".jpg") or f.endswith(".png"))])
        for archivo in archivos:
            path_img = os.path.join(ruta_carpeta, archivo)
            img = pygame.image.load(path_img).convert()
            frames.append(pygame.transform.scale(img, (ANCHO, ALTO)))
    return frames

frames_menu = cargar_frames_carpeta("menu", "menu")
frames_menu1 = cargar_frames_carpeta("menu1", "menu1")

fondos_niveles = {}
for i in range(1, 9):
    fondos_niveles[i] = cargar_frames_carpeta(f"fondo{i}", f"fondo{i}_")

frames_lluvia = cargar_frames_carpeta("img", "ezgif-frame-")
idx_menu, idx_menu1, idx_juego = 0.0, 0.0, 0.0

# --- CARGAR NIVELES ---
def cargar_nivel(num_nivel):
    global tiempo_instruccion
    tiempo_instruccion = 240
    
    plataformas = pygame.sprite.Group()
    enemigos = pygame.sprite.Group()
    hermana_group = pygame.sprite.Group()
    poderes_group = pygame.sprite.Group()
    
    suelo = Plataforma(0, 380, ANCHO, 100)
    plataformas.add(suelo)

    if num_nivel == 0:
        plataformas.add(Plataforma(250, 290, 140, 20))
    elif num_nivel == 1:
        plataformas.add(Plataforma(200, 290, 120, 20), Plataforma(420, 220, 120, 20))
        enemigos.add(EnemigoBase(430, 185, rango_mov=40, velocidad=2, dispara=True))
    elif num_nivel == 2:
        plataformas.add(Plataforma(150, 300, 100, 20), Plataforma(320, 230, 120, 20))
        plataformas.add(Plataforma(280, 360, 50, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(330, 195, rango_mov=50, velocidad=2, dispara=True))
    elif num_nivel == 3:
        plataformas.add(Plataforma(180, 270, 90, 20), Plataforma(350, 270, 90, 20), Plataforma(520, 210, 90, 20))
        plataformas.add(Plataforma(200, 360, 220, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(530, 175, rango_mov=30, velocidad=3, dispara=True))
    elif num_nivel == 4:
        plataformas.add(Plataforma(120, 300, 90, 20), Plataforma(260, 220, 100, 20), Plataforma(440, 280, 100, 20))
        enemigos.add(EnemigoBase(270, 185, rango_mov=40, velocidad=3, dispara=True))
        enemigos.add(EnemigoBase(450, 245, rango_mov=40, velocidad=3, dispara=True))
    elif num_nivel == 5:
        plataformas.add(Plataforma(100, 310, 70, 20), Plataforma(230, 250, 70, 20), Plataforma(360, 190, 70, 20), Plataforma(490, 130, 80, 20))
        plataformas.add(Plataforma(150, 360, 280, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(500, 95, rango_mov=30, velocidad=3, dispara=True))
    elif num_nivel == 6:
        plataformas.add(Plataforma(160, 280, 100, 20), Plataforma(380, 220, 120, 20))
        plataformas.add(Plataforma(220, 360, 60, 20, es_obstaculo=True), Plataforma(480, 360, 60, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(100, 345, rango_mov=60, velocidad=4, dispara=True))
        enemigos.add(EnemigoBase(390, 185, rango_mov=50, velocidad=4, dispara=True))
    elif num_nivel == 7:
        plataformas.add(Plataforma(250, 240, 100, 20), Plataforma(450, 180, 90, 20))
        plataformas.add(Plataforma(100, 360, 100, 20, es_obstaculo=True), Plataforma(300, 360, 100, 20, es_obstaculo=True), Plataforma(500, 360, 100, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(260, 205, rango_mov=40, velocidad=4, dispara=True))
    elif num_nivel == 8:
        plataformas.add(Plataforma(150, 280, 100, 20), Plataforma(350, 220, 100, 20), Plataforma(580, 160, 120, 20))
        plataformas.add(Plataforma(220, 360, 250, 20, es_obstaculo=True))
        enemigos.add(EnemigoBase(360, 165, rango_mov=120, velocidad=4, es_jefe=True, vida=6, dispara=True))
        hermana_group.add(Hermana(650, 115))

    puerta = PuertaCueva(ANCHO - 60, 315 if num_nivel != 8 else 95)
    return plataformas, enemigos, puerta, hermana_group, poderes_group

caballero = PlayerChar(50, 280)
grupo_sprites = pygame.sprite.Group(caballero)
grupo_plataformas, grupo_enemigos, puerta_salida, grupo_hermana, grupo_poderes = cargar_nivel(nivel_actual)

# INTERFAZ Y BOTONES
btn_jugar_main = pygame.Rect(ANCHO // 2 - 90, ALTO // 2 + 20, 180, 45)
btn_reintentar = pygame.Rect(ANCHO // 2 - 90, ALTO // 2 + 30, 180, 45)
btn_volver = pygame.Rect(20, ALTO - 50, 110, 35)
btn_retroceder_hud = pygame.Rect(12, 12, 36, 32)

botones_niveles = [(0, "📖 TUTORIAL", pygame.Rect(ANCHO // 2 - 110, 85, 220, 36))]
for i in range(1, 9):
    col = 0 if i <= 4 else 1
    fila = (i - 1) % 4
    x = ANCHO // 2 - 165 if col == 0 else ANCHO // 2 + 10
    y = 130 + (fila * 44)
    botones_niveles.append((i, f"CAPÍTULO {i}", pygame.Rect(x, y, 155, 36)))

area_izq = pygame.Rect(15, ALTO - 80, 65, 65)
area_der = pygame.Rect(90, ALTO - 80, 65, 65)
area_ataque = pygame.Rect(ANCHO - 150, ALTO - 80, 65, 65)
area_salto = pygame.Rect(ANCHO - 75, ALTO - 80, 65, 65)

toques_activos = {}

def obtener_pos_evento(evento):
    if evento.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
        return (int(evento.x * ANCHO), int(evento.y * ALTO))
    elif evento.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
        return evento.pos
    return None

# --- BUCLE PRINCIPAL ---
ejecutando = True
while ejecutando:
    reloj.tick(FPS)
    pos_mouse = pygame.mouse.get_pos()
    
    if tiempo_invulnerable > 0:
        tiempo_invulnerable -= 1
    if tiempo_instruccion > 0:
        tiempo_instruccion -= 1

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

        pos_evt = obtener_pos_evento(evento)

        if estado_actual == ESTADO_MENU_PRINCIPAL:
            if evento.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) and pos_evt:
                if btn_jugar_main.collidepoint(pos_evt):
                    estado_actual = ESTADO_SELECCION_HISTORIA

        elif estado_actual == ESTADO_SELECCION_HISTORIA:
            if evento.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) and pos_evt:
                for id_lvl, nombre, rect in botones_niveles:
                    if rect.collidepoint(pos_evt) and id_lvl <= nivel_maximo_desbloqueado:
                        nivel_actual = id_lvl
                        vida_actual = vida_maxima
                        grupo_plataformas, grupo_enemigos, puerta_salida, grupo_hermana, grupo_poderes = cargar_nivel(nivel_actual)
                        caballero.rect.topleft = (50, 280)
                        estado_actual = ESTADO_JUEGO
                        break
                if btn_volver.collidepoint(pos_evt):
                    estado_actual = ESTADO_MENU_PRINCIPAL

        elif estado_actual in [ESTADO_GAME_OVER, ESTADO_VICTORIA]:
            if evento.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) and pos_evt:
                if btn_reintentar.collidepoint(pos_evt):
                    vida_actual = vida_maxima
                    if estado_actual == ESTADO_VICTORIA:
                        nivel_actual = 0
                    grupo_plataformas, grupo_enemigos, puerta_salida, grupo_hermana, grupo_poderes = cargar_nivel(nivel_actual)
                    caballero.rect.topleft = (50, 280)
                    estado_actual = ESTADO_JUEGO

        elif estado_actual == ESTADO_JUEGO:
            if evento.type == pygame.KEYDOWN:
                if evento.key in (pygame.K_UP, pygame.K_SPACE, pygame.K_w):
                    caballero.saltar()
                elif evento.key == pygame.K_j:
                    caballero.atacar()
                elif evento.key == pygame.K_ESCAPE:
                    estado_actual = ESTADO_SELECCION_HISTORIA

            if evento.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) and pos_evt:
                if btn_retroceder_hud.collidepoint(pos_evt):
                    estado_actual = ESTADO_SELECCION_HISTORIA

            # EVENTOS TÁCTILES Y DE CLICK CONTINUOS EN PANTALLA
            if evento.type in (pygame.FINGERDOWN, pygame.FINGERMOTION):
                toques_activos[evento.finger_id] = pos_evt
                if evento.type == pygame.FINGERDOWN:
                    if area_salto.collidepoint(pos_evt):
                        caballero.saltar()
                    elif area_ataque.collidepoint(pos_evt):
                        caballero.atacar()

            elif evento.type == pygame.FINGERUP:
                if evento.finger_id in toques_activos:
                    del toques_activos[evento.finger_id]

            elif evento.type == pygame.MOUSEBUTTONDOWN:
                if area_salto.collidepoint(evento.pos):
                    caballero.saltar()
                elif area_ataque.collidepoint(evento.pos):
                    caballero.atacar()

    if estado_actual == ESTADO_JUEGO:
        mov_x = 0
        teclas = pygame.key.get_pressed()
        
        if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
            mov_x = -VELOCIDAD_JUGADOR
        elif teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
            mov_x = VELOCIDAD_JUGADOR

        # Detección de movimiento por mouse (PC) o pantalla táctil (Móvil)
        mouse_press = pygame.mouse.get_pressed()
        if mouse_press[0]:
            if area_izq.collidepoint(pos_mouse):
                mov_x = -VELOCIDAD_JUGADOR
            elif area_der.collidepoint(pos_mouse):
                mov_x = VELOCIDAD_JUGADOR

        for _, pos in toques_activos.items():
            if area_izq.collidepoint(pos):
                mov_x = -VELOCIDAD_JUGADOR
            elif area_der.collidepoint(pos):
                mov_x = VELOCIDAD_JUGADOR

        caballero.move_x(mov_x)

    # --- RENDERIZADO ---
    pantalla.fill(COLOR_BG_DARK)

    if estado_actual == ESTADO_MENU_PRINCIPAL:
        if frames_menu:
            pantalla.blit(frames_menu[int(idx_menu)], (0, 0))
            idx_menu = (idx_menu + 0.25) % len(frames_menu)
            
        txt_t = fuente_titulo.render("HOLLOW KNIGHT", True, COLOR_ACCENT_GOLD)
        pantalla.blit(txt_t, txt_t.get_rect(center=(ANCHO // 2, ALTO // 2 - 40)))
        dibujar_boton_moderno(pantalla, btn_jugar_main, "JUGAR", resaltado=btn_jugar_main.collidepoint(pos_mouse))

    elif estado_actual == ESTADO_SELECCION_HISTORIA:
        if frames_menu1:
            pantalla.blit(frames_menu1[int(idx_menu1)], (0, 0))
            idx_menu1 = (idx_menu1 + 0.25) % len(frames_menu1)
            
        txt_tit = fuente_titulo.render("SELECCIÓN DE NIVEL", True, COLOR_ACCENT_GOLD)
        pantalla.blit(txt_tit, txt_tit.get_rect(center=(ANCHO // 2, 40)))
        
        for id_lvl, nombre, rect in botones_niveles:
            desbloqueado = id_lvl <= nivel_maximo_desbloqueado
            dibujar_boton_moderno(pantalla, rect, nombre if desbloqueado else f"🔒 {nombre}", activo=desbloqueado, resaltado=rect.collidepoint(pos_mouse) and desbloqueado)
            
        dibujar_boton_moderno(pantalla, btn_volver, "VOLVER", resaltado=btn_volver.collidepoint(pos_mouse))

    elif estado_actual == ESTADO_JUEGO:
        grupo_sprites.update(grupo_plataformas)
        grupo_enemigos.update(grupo_poderes, caballero.rect.center)
        grupo_poderes.update()

        if caballero.atacando:
            rango_ataque = caballero.rect.inflate(30, 10)
            for enemigo in grupo_enemigos:
                if rango_ataque.colliderect(enemigo.rect):
                    enemigo.recibir_dano(1)

        for poder in grupo_poderes:
            if caballero.rect.colliderect(poder.rect):
                recibir_dano(15)
                poder.kill()

        for enemigo in grupo_enemigos:
            if caballero.rect.colliderect(enemigo.rect):
                recibir_dano(30 if enemigo.es_jefe else 20)

        for plat in grupo_plataformas:
            if plat.es_obstaculo and caballero.rect.colliderect(plat.rect):
                recibir_dano(25)

        if nivel_actual == 8 and pygame.sprite.spritecollideany(caballero, grupo_hermana):
            estado_actual = ESTADO_VICTORIA

        elif nivel_actual < 8 and caballero.rect.colliderect(puerta_salida.rect):
            nivel_actual += 1
            if nivel_actual > nivel_maximo_desbloqueado:
                nivel_maximo_desbloqueado = nivel_actual
            vida_actual = vida_maxima
            grupo_plataformas, grupo_enemigos, puerta_salida, grupo_hermana, grupo_poderes = cargar_nivel(nivel_actual)
            caballero.rect.topleft = (50, 280)

        frames_nivel = fondos_niveles.get(nivel_actual, frames_lluvia)
        if frames_nivel:
            pantalla.blit(frames_nivel[int(idx_juego)], (0, 0))
            idx_juego = (idx_juego + 0.25) % len(frames_nivel)

        grupo_plataformas.draw(pantalla)
        if nivel_actual < 8:
            pantalla.blit(puerta_salida.image, puerta_salida.rect)
        
        grupo_hermana.draw(pantalla)

        if tiempo_invulnerable % 4 < 2:
            grupo_sprites.draw(pantalla)
        
        grupo_enemigos.draw(pantalla)
        grupo_poderes.draw(pantalla)

        for e in grupo_enemigos:
            if e.es_jefe:
                dibujar_barra_vida_moderna(pantalla, ANCHO // 2 - 80, 15, e.vida, e.vida_max, "JEFE")

        dibujar_barra_vida_moderna(pantalla, 55, 16, vida_actual, vida_maxima)
        dibujar_boton_moderno(pantalla, btn_retroceder_hud, "←")

        def dibujar_control_tactil(rect, es_presionado, icono):
            surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            color_fondo = COLOR_BTN_TACTIL_ACTIVO if es_presionado else COLOR_BTN_TACTIL
            color_borde = COLOR_NEON_BLUE if es_presionado else (255, 255, 255, 120)
            
            pygame.draw.rect(surf, color_fondo, (0, 0, rect.width, rect.height), border_radius=16)
            pygame.draw.rect(surf, color_borde, (0, 0, rect.width, rect.height), width=2, border_radius=16)
            pantalla.blit(surf, rect.topleft)

            if icono == "IZQ":
                pygame.draw.polygon(pantalla, COLOR_TEXT_MAIN, [(rect.right - 18, rect.top + 16), (rect.left + 16, rect.centery), (rect.right - 18, rect.bottom - 16)])
            elif icono == "DER":
                pygame.draw.polygon(pantalla, COLOR_TEXT_MAIN, [(rect.left + 18, rect.top + 16), (rect.right - 16, rect.centery), (rect.left + 18, rect.bottom - 16)])
            elif icono == "SALTO":
                pygame.draw.polygon(pantalla, COLOR_ACCENT_GOLD, [(rect.left + 16, rect.bottom - 18), (rect.centerx, rect.top + 16), (rect.right - 16, rect.bottom - 18)])
            elif icono == "ATAKE":
                pygame.draw.circle(pantalla, COLOR_NEON_RED, rect.center, 18, width=3)

        puntos_entrada = list(toques_activos.values())
        if pygame.mouse.get_pressed()[0]:
            puntos_entrada.append(pos_mouse)

        izq_pres = any(area_izq.collidepoint(pt) for pt in puntos_entrada)
        der_pres = any(area_der.collidepoint(pt) for pt in puntos_entrada)
        salto_pres = any(area_salto.collidepoint(pt) for pt in puntos_entrada)
        atake_pres = any(area_ataque.collidepoint(pt) for pt in puntos_entrada)

        dibujar_control_tactil(area_izq, izq_pres, "IZQ")
        dibujar_control_tactil(area_der, der_pres, "DER")
        dibujar_control_tactil(area_salto, salto_pres, "SALTO")
        dibujar_control_tactil(area_ataque, atake_pres, "ATAKE")

        if tiempo_instruccion > 0:
            dibujar_dialogo_moderno(pantalla, INSTRUCCIONES_NIVELES.get(nivel_actual, ""))

    elif estado_actual == ESTADO_MUERTE_ANIMACION:
        frames_nivel = fondos_niveles.get(nivel_actual, frames_lluvia)
        if frames_nivel:
            pantalla.blit(frames_nivel[int(idx_juego)], (0, 0))
        grupo_plataformas.draw(pantalla)
        
        vel_caida_muerte += 0.8
        caballero.rect.y += int(vel_caida_muerte)
        
        if img_muerte:
            sprite_muerto = pygame.transform.scale(img_muerte, (caballero.rect.width, caballero.rect.height))
            pantalla.blit(sprite_muerto, caballero.rect)
        else:
            img_caida = pygame.transform.rotate(caballero.image, 90)
            pantalla.blit(img_caida, caballero.rect)

        if caballero.rect.top > ALTO:
            estado_actual = ESTADO_GAME_OVER

    elif estado_actual == ESTADO_GAME_OVER:
        pantalla.fill((12, 6, 12))
        txt_go = fuente_gameover.render("HAS MUERTO", True, COLOR_NEON_RED)
        pantalla.blit(txt_go, txt_go.get_rect(center=(ANCHO // 2, ALTO // 2 - 30)))
        dibujar_boton_moderno(pantalla, btn_reintentar, "REINTENTAR", resaltado=btn_reintentar.collidepoint(pos_mouse))

    elif estado_actual == ESTADO_VICTORIA:
        pantalla.fill((10, 18, 30))
        txt_vic = fuente_gameover.render("¡VICTORIA!", True, COLOR_ACCENT_GOLD)
        txt_sub = fuente_menu.render("Has derrotado al jefe y rescatado a tu hermana.", True, COLOR_TEXT_MAIN)
        pantalla.blit(txt_vic, txt_vic.get_rect(center=(ANCHO // 2, ALTO // 2 - 40)))
        pantalla.blit(txt_sub, txt_sub.get_rect(center=(ANCHO // 2, ALTO // 2)))
        dibujar_boton_moderno(pantalla, btn_reintentar, "MENÚ INICIAL", resaltado=btn_reintentar.collidepoint(pos_mouse))

    pygame.display.flip()

pygame.font.quit()
pygame.quit()
sys.exit()