[app]
title = Hollow Knight Mobile
package.name = hollowknightmobile
package.domain = org.juego
source.dir = .
source.include_exts = py,png,jpg,jpeg,ttf,wav,ogg,json,mp3,atlas
source.main = main.py
version = 0.1
requirements = python3,kivy
orientation = landscape
fullscreen = 1
android.permissions = INTERNET
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_licenses = True

[buildozer]
log_level = 2
warn_on_root = 1